Thanks for stopping by! This repository is the home for Azure DevOps .NET samples.
We're happy to help with bugs, support, and feature requests for the samples.
This isn't the right channel for bugs, support, and feature requests for the product.

Before you file an issue, please review this checklist:

* Bug report for the product? https://developercommunity.visualstudio.com/
* Support request? https://azure.microsoft.com/support/devops/
* Feature request? https://developercommunity.visualstudio.com/

 Still here? Great! You can delete this text and file your issue.
